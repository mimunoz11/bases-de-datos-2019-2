from flask import Flask, render_template, request, abort, json
from pymongo import MongoClient
import pandas as pd
import matplotlib.pyplot as plt
import os
import atexit
import subprocess
import datetime
MESSAGE_KEYS = ['content', 'metadata']
# Levantamos el servidor de mongo. Esto no es necesario, puede abrir
# una terminal y correr mongod. El DEVNULL hace que no vemos el output
# mongod = subprocess.Popen('mongod', stdout=subprocess.DEVNULL)
# Nos aseguramos que cuando el programa termine, mongod no quede corriendo
# atexit.register(mongod.kill)
# El cliente se levanta en localhost:5432
grupo = "6"
URL = f"mongodb://grupo{grupo}:grupo{grupo}@gray.ing.puc.cl/grupo{grupo}"
client = MongoClient(URL)
# Utilizamos la base de datos 'entidades'
db = client["grupo6"]
# Seleccionamos la colección de usuarios
mensajes = db.messages
# Iniciamos la aplicación de flask
app = Flask(__name__)

@app.route("/")
def home():
    return "<h1>¡Te damos la bienvenida!</h1>\
    <div>API Grupo 6 & 23</div>"
# Mapeamos esta función a la ruta '/plot' con el método get.


@app.route("/messages")
def get_messages():
    resultados = [m for m in mensajes.find({}, {"_id": 0})]
    # https://www.tutorialspoint.com/mongodb-query-to-get-last-inserted-document
    # Omitir el _id porque no es json serializable
    return json.jsonify(resultados)

@app.route("/messages/<string:id>")
def get_message(id):
    messages = list(mensajes.find({"id": id}, {"_id": 0}))
    return json.jsonify(messages)
    

@app.route("/messages/project-search",methods=['GET'])
def project_search():
    # http://lineadecodigo.com/python/parametros-get-flask/
    try:
        nombre = request.args.get('nombre')
        messages = list(mensajes.find({ "$or": [{"metadata.sender": nombre}, {"metadata.receiver": nombre}]}, {"_id": 0}))
        return json.jsonify(messages)    
    except:
        return json.jsonify([])
    
@app.route("/messages/content-search")
def content_search():
    try:
        solicitud = request.json
        busqueda = {key: ((([str(i) for i in solicitud[key]]) if (type(solicitud[key]) == list) else str(solicitud[key])) if key in solicitud.keys() else []) for key in ["desired", "required", "forbidden"]}
        busqueda["forbidden"] = busqueda["forbidden"] if type(busqueda["forbidden"]) == list else busqueda["forbidden"].split(" ")
        busqueda["desired"] = busqueda["desired"] if type(busqueda["desired"]) == list else busqueda["desired"].split(" ")
        busqueda["required"] = busqueda["required"] if type(busqueda["required"]) == list else busqueda["required"].split(" ")
        bus_for = busqueda["forbidden"]
        string_forbidden = "".join(busqueda["forbidden"]).strip()
        string_required = "".join(busqueda["required"]).strip()
        string_desired = "".join(busqueda["desired"]).strip()
        if (not string_forbidden) and (not string_required) and (not string_desired):
            messages = list(mensajes.find({}, {"_id": 0}))
        elif (not string_required) and (not string_desired):
            no_encontrar = " ".join([f"{i}" for i in busqueda["forbidden"] if i])
            no_encontrados = [i["id"] for i in list(mensajes.find({"$text": {"$search": no_encontrar}}, {"id": 1, "_id": 0}))]
            #return json.jsonify(no_encontrados)
            messages = list(mensajes.find({"id": {"$nin": no_encontrados}}, {"_id": 0}))
            #messages = list([])
            
        else:
            busqueda["forbidden"] = " ".join([(f"-{i}" if " " not in i else f"-\"{i}\"") for i in busqueda["forbidden"] if i])
            busqueda["required"] = " ".join([f"\"{i}\"" for i in busqueda["required"] if i])
            busqueda["desired"] = " ".join(busqueda["desired"])
            #return json.jsonify([busqueda])
            #return json.jsonify(f"{busqueda['desired']} {busqueda['forbidden']} {busqueda['required']}")
            messages = list(mensajes.find({"$text": {"$search": f"{busqueda['desired']} {busqueda['forbidden']} {busqueda['required']}"}}, {"_id": 0}))
            if (not len(messages)) and busqueda["forbidden"] and (not busqueda["required"]):
                busqueda["forbidden"] = bus_for
                no_encontrar = " ".join([f"{i}" for i in busqueda["forbidden"] if i])
                no_encontrados = [i["id"] for i in list(mensajes.find({"$text": {"$search": no_encontrar}}, {"id": 1, "_id": 0}))]
                #return json.jsonify(no_encontrados)
                messages = list(mensajes.find({"id": {"$nin": no_encontrados}}, {"_id": 0}))
                #messages = list([])

        return json.jsonify(messages)
    except:
        return json.jsonify([False, "Ocurrió un error en la búsqueda"])

@app.route("/messages", methods=['POST'])
def create_message():
    '''
    Crea un nuevo mensaje en la base de datos
    Se necesitan todos los atributos de model, a excepcion de _id
    '''
    try:
        # Si los parámetros son enviados con una request de tipo application/json:
        data = {key: request.json[key] for key in MESSAGE_KEYS}
        # Se genera el uid
        #count = mensajes.count_documents({})
        count = int([m["id"] for m in mensajes.find({}).sort("_id", -1).limit(1)][0])
        try:
            mensaje_id = count + 1
            while mensajes.count_documents({"id": str(mensaje_id)}):
                mensaje_id += 1
        except IndexError:
            mensaje_id = 1
        data["id"] = str(mensaje_id)

        date_actual = datetime.datetime.today().strftime("%Y-%m-%d %H:%M:%S")
        data["metadata"]["time"] = date_actual
        # Insertar retorna un objeto
        result = mensajes.insert_one(data)
        # Creo el mensaje resultado
        if (result):
            message = f"Mensaje con id={data['id']} fue creado exitosamente (time={date_actual})"
            success = True
        else:
            message = "No se pudo crear el mensaje"
            success = False
        # Retorno el texto plano de un json
        return json.jsonify({'success': success, 'message': message})
    except:
        return json.jsonify({"success": False, "message": "Ocurrió un error durante la creación del mensaje."})

@app.route('/messages/<string:id>', methods=['DELETE'])
def delete_message(id):
    '''
    Elimina un mensaje de la db.
    Se requiere llave id
    ''' 
    try:
        # esto borra el primer resultado. si hay mas, no los borra
        resultado = mensajes.delete_one({"id": id})
        if resultado.deleted_count == 0:
            message = f'No existe mensaje con id={id}.'
            return json.jsonify({'result': 'failure', 'message': message})
        else:
            message = f'Mensaje con id={id} ha sido eliminado.'
            return json.jsonify({'result': 'success', 'message': message})
        # Retorno el texto plano de un json
    except:
        return json.jsonify({"success": False, "message": "Ocurrió un error al intentar eliminar el mensaje."})



if os.name == 'nt':
    app.run(debug=True)
